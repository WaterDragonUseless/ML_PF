function  PlotGABP()

load('C:\Users\lenovo\Dropbox\ML_power_flow_Tongyi_145\Author''s code\GA+BP VS BP\test_simBP_9.mat')
load('C:\Users\lenovo\Dropbox\ML_power_flow_Tongyi_145\Author''s code\GA+BP VS BP\test_simBPGA_9.mat')
load('C:\Users\lenovo\Dropbox\ML_power_flow_Tongyi_145\Author''s code\GA+BP VS BP\test_real_9.mat')



[num_bus_row,num_bus_column] = size(test_real);

deltaBP = abs(test_real -test_simu0)*100./abs(test_real);
deltaBPGA = abs(test_real(1:num_bus_row,:) -test_simu1(1:num_bus_row,:))*100./abs(test_real(1:num_bus_row,:));

figure(1);%TOTAL SAMPLES
mesh(1:num_bus_column,1:num_bus_row, deltaBP, 'edgecolor','r')
%title 'Percentage P error (BP) ';
xlabel ('Samples');
ylabel('Bus');
zlabel('Error P(%)');

temp = deltaBP;
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.p_BP = mean(mean(temp)) * 100;
 

figure(2);%TOTAL SAMPLES
mesh(1:num_bus_column,1:num_bus_row, deltaBPGA, 'edgecolor','r')
%title 'Percentage P error (BP+GA) ';
xlabel ('Samples');
ylabel('Bus');
zlabel('Error P(%)');

temp = deltaBPGA;
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.p_BPGA = mean(mean(temp)) * 100;

%%read xls.x
load bpvsbpga.mat;


figure(3);
plot(ans(1:11, 1),ans(1:11, 2),'b-*');
hold on 
plot(ans(1:11, 1),ans(1:11, 3),'mo-');
xlabel('IEEE cases');
ylabel('Log(error)');
legend('BP error','BP+GA error');
hold off

