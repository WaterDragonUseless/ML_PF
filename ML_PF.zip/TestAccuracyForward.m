function [delta, test] = ...
    TestAccuracyForward(num_train, data, Xp,Xp_cos, Xq, Xp_dlpf, Xq_dlpf, B, Xpt, Xqt)
% this function test the accuracy of forward regression
%% calculate the results by data-driven linearized equations
for i = 1:num_train

    test.p.fitting(i, :) = [data.Va(i,:) * pi / 180 data.V(i,:) 1] * Xp';
    test.p.fitting_cos(i, :) = [cos(data.Va(i,:) * pi / 180) data.V(i,:) 1] * Xp';
    test.p.dcpf(i, :) = B * data.Va(i, :)' * pi / 180;
    test.p.dlpf(i, :) = [data.Va(i,:) * pi / 180 data.V(i,:)]*Xp_dlpf';
    test.q.fitting(i, :) = [data.Va(i,:) * pi / 180 data.V(i,:) 1]*Xq';
    test.q.dlpf(i, :) = [data.Va(i,:) * pi / 180 data.V(i,:)]*Xq_dlpf';
end

[num_bus_row,num_bus_column] = size(data.P);

%%Plot diagram

error.ls = abs(data.P -test.p.fitting)*100./abs(data.P);
error.dlpf = abs(data.P -test.p.dlpf)*100./abs(data.P);
error.dcpf = abs(data.P -test.p.dcpf)*100./abs(data.P);
figure(1);%TOTAL SAMPLES
s = mesh(1:num_bus_column,1:num_bus_row, error.ls);
colorbar;
ylabel ('Samples');
xlabel('Bus');
zlabel('Error P(%)');
title 'Least Square: Active Power error in from bus 1 to bus 30'

figure(2);%TOTAL SAMPLES
s = mesh(1:num_bus_column,1:num_bus_row, error.dcpf);
colorbar;
ylabel ('Samples');
xlabel('Bus');
zlabel('Error P(%)');
title 'DCPF: Active Power error in from bus 1 to bus 30'

figure(3);%TOTAL SAMPLES
s = mesh(1:num_bus_column,1:num_bus_row, error.dlpf);
colorbar;
ylabel ('Samples');
xlabel('Bus');
zlabel('Error P(%)');
title 'DLPF: Active Power error in from bus 1 to bus 30'

%% calculate the errors, note that the value of nan or inf is removed
%data. is the "real value", test. is the calculated by model 

error.ls = abs(data.P -test.p.fitting)*100./abs(data.P);
error.dlpf = abs(data.P -test.p.dlpf)*100./abs(data.P);
temp = abs((data.P - test.p.fitting)./data.P);
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.p.fitting = mean(mean(temp)) * 100;



temp = abs((data.P - test.p.dcpf)./data.P);
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.p.dcpf = mean(mean(temp)) * 100;

temp = abs((data.P - test.p.dlpf)./data.P);
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.p.dlpf = mean(mean(temp)) * 100;


%%plot reactive power error

error.ls = abs(data.Q -test.q.fitting)*100./abs(data.Q);
error.dlpf = abs(data.Q -test.q.dlpf)*100./abs(data.Q);

figure(4);%TOTAL SAMPLES
s = mesh(1:num_bus_column,1:num_bus_row, error.ls);
colorbar;
title 'Least Square: Reactive Power error in from bus 1 to bus 30'
ylabel ('Samples');
xlabel('Bus');
zlabel('Error Q(%)');


figure(5);%TOTAL SAMPLES
s = mesh(1:num_bus_column,1:num_bus_row, error.dlpf);
colorbar;
title 'DLPF: Reactive Power error in from bus 1 to bus 30'
ylabel ('Samples');
xlabel('Bus');
zlabel('Error Q(%)');


%%calculate reactive power error
temp = abs((data.Q - test.q.fitting)./data.Q);
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.q.fitting = mean(mean(temp)) * 100;


temp = abs((data.Q - test.q.dlpf)./data.Q);
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.q.dlpf = mean(mean(temp)) * 100;


%%-----------------------------------------------------------------------
%%set a stop here 


V_Va_1 = [data.Va * pi / 180 data.V];
test.p.BP = sim(Xpt, V_Va_1'); %p
test.q.BP = sim(Xqt, V_Va_1');%q

data.P = data.P';
data.Q = data.Q';

[num_bus_row,num_bus_column] = size(data.P);

temp = abs(data.P -test.p.BP)./abs(data.P); %funtion 1:Levenberg-Marquardt
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.p.BP = mean(mean(temp)) * 100;

test.q.BP(:,1:40) = data.Q(:, 1:40);
temp = abs(data.Q -test.q.BP)./abs(data.Q); %funtion 1:Levenberg-Marquardt
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.q.BP = mean(mean(temp)) * 100;


