function [theta_1, cos_1, sin_1]=TestAccuracySinCos(net_p_1,Xp,Xp_cos,data,j)

V_Va_1 = [data.Va * pi / 180 data.V];
V_cosVa_p = [cos(data.Va * pi / 180) data.V] %use sin(theta) as input
V_sinVa_p = [sin(data.Va * pi / 180) data.V] %use sin(theta) as input
data_p_3 = sim(net_p_1, V_Va_1'); %cos
data_p_1 = sim(Xp_cos, V_cosVa_p'); %cos
data_q_1 = sim(Xp, V_sinVa_p');%sin

 data.P = data.P';
 data.Q = data.Q';
 temp = abs((data.P -data_p_3)); %theta
 theta_1 = mean(mean(temp)) * 1000;

 temp = abs((data.P -data_p_1)); %cos
 cos_1 = mean(mean(temp)) * 1000;
 
 temp = abs((data.P -data_q_1)); %sin
 sin_1 = mean(mean(temp)) * 1000;
