function [Xp, Xp_cos, Xq, Xpf, Xqf, Xpt, Xqt, net_p_1, net_p_2, net_p_3, net_q_1, net_q_2, net_q_3] =...
    RegressionForward(regression, num_load, data, address, case_name)
% this function conduct the forward regression by calling different regressioin algorithms
switch regression
    case 0 % ordinary least squares  Y = A*X
        for i = 1:num_load 
            p = data.P(:, i); %make Y
            V_Va_p = [data.Va * pi / 180 data.V ones(size(data.V, 1), 1)];%make A
            V_cosVa_p = [cos(data.Va * pi / 180) data.V ones(size(data.V, 1), 1)];%make A
            b = regress(p, V_Va_p);
            b_cos = regress(p, V_cosVa_p);
            Xp(i, :) = b';% make X
            Xp_cos(i,:) = b_cos';
            q = data.Q(:, i);
            V_Va_q = [data.Va * pi / 180 data.V ones(size(data.V, 1), 1)];
            b = regress(q, V_Va_q);
            Xq(i, :) = b';
        end
        
        V_Va_p = [data.Va * pi / 180 data.V];
        layer1_neurons = 10;       
        net = fitnet(layer1_neurons,'trainlm');
        Xpt= train(net,V_Va_p', data.P');

        layer1_neurons = 40;       
        net = fitnet(layer1_neurons,'trainlm');
        Xqt = train(net, V_Va_p', data.Q');% network is stored in Xp

        net_q_1 = [];
        net_q_2 = [];
        net_q_3 = [];
        net_p_1 = [];
        net_p_2 = [];
        net_p_3 = [];
        Xpf = [];
        Xqf = [];



    case 1 % partial least squares
        k = rank(data.V) + rank(data.Va);
        k = min(k, size(data.P,1)-1);
        X_pls = [data.Va * pi / 180 data.V];
        Y_p_pls = data.P;
        [~,~,~,~,Xp] = plsregress(X_pls, Y_p_pls, k);
        % X_pls is predictor variable matrix (angle and magnitude)
        % Y_p_pls is response matrix
        % Xp is pls coefficient 
        %X=CT'+E  C = scroe matrix of x
        %Y=RU'+F, R = score matrix of R

        Xp = Xp';
        temp = Xp(:,1);
        Xp(:,1) = [];   
        Xp = [Xp temp]; %put the first colomn into the last colomn

        Y_q_pls = data.Q;
        [~,~,~,~,Xq] = plsregress(X_pls, Y_q_pls, k);
        Xq = Xq';
        temp = Xq(:,1);Xq(:,1) = [];Xq = [Xq temp];
        
        net_q_1 = [];
        net_q_2 = [];
        net_q_3 = [];
        Xp_cos = [];
        net_p_1 = [];
        net_p_2 = [];
        net_p_3 = [];
        Xpf = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];

    case 2 % bayesian linear regression
        threshold = 10000;
        X = [data.Va * pi / 180 data.V];
        Y = [data.P data.Q];
        X_blr = BayesianLR_python( X,Y ,threshold, address, case_name);
        [row, ~] = size(X_blr);
        row = row/2;
        Xp = X_blr(1:row, :);
        Xq = X_blr(row + 1:2 * row, :);

        net_q_1 = [];
        net_q_2 = [];
        net_q_3 = [];
        net_p_1 = [];
        net_p_2 = [];
        net_p_3 = [];
        Xpf = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];

    case 3 %neuralnetwork-changing different algorithms
        layer1_neurons = 7;
        V_Va_p = [data.Va * pi / 180 data.V];

        %using different functions
        %https://uk.mathworks.com/help/deeplearning/ref/fitnet.html;jsessionid=c405e675a99838b5366dd07f37b4#d124e239928
        net = fitnet(layer1_neurons,'trainlm');%funtion 1:Levenberg-Marquardt
        net_p_1 = train(net,V_Va_p', data.P');
        znet = fitnet(layer1_neurons,'traingd');%funtion 3: Gradient Descent
        net_p_3 = train(net,V_Va_p', data.P');
         
        net = fitnet(layer1_neurons,'trainlm');%funtion 1:Levenberg-Marquardt
        net_q_1 = train(net,V_Va_p', data.Q');
        net = fitnet(layer1_neurons,'traingd');
        net_q_3 = train(net, V_Va_p', data.Q');

        net_q_2 = [];
        net_p_2 = [];
        Xp_cos = [];
        Xq  = [];
        Xp  = [];
        Xpf = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];


    case 4 %neuralnetwork-changing different number of neurons 
           % net_p_1,  net_p_2,  net_p_3... Xp area used to store net in
           % different internal layers 
 
        V_Va_p = [data.Va * pi / 180 data.V];
         for layer1_neurons = 4:12
             if(layer1_neurons==4)
                  net = fitnet(layer1_neurons,'traingd');%funtion 1:Levenberg-Marquardt
                  net_p_1 = train(net,V_Va_p', data.P');
             end
              if(layer1_neurons==5)
                 net = fitnet(layer1_neurons,'traingd');%funtion 1:Levenberg-Marquardt
                 net_p_2 = train(net,V_Va_p', data.P');
              end
               if(layer1_neurons==6)
                 net = fitnet(layer1_neurons,'traingd');%funtion 1:Levenberg-Marquardt
                 net_p_3 = train(net,V_Va_p', data.P');
               end
               if(layer1_neurons==7)
                   net = fitnet(layer1_neurons,'traingd');%funtion 1:Levenberg-Marquardt
                   net_q_1 = train(net,V_Va_p', data.P');
               end
               if(layer1_neurons==8)
                  net = fitnet(layer1_neurons,'traingd');%funtion 1:Levenberg-Marquardt
                  net_q_2 = train(net,V_Va_p', data.P');
               end
               if(layer1_neurons==9)
                  net = fitnet(layer1_neurons,'traingd');%funtion 1:Levenberg-Marquardt
                  net_q_3 = train(net,V_Va_p', data.P');
             end
             if(layer1_neurons==10)
                  net = fitnet(layer1_neurons,'traingd');%funtion 1:Levenberg-Marquardt
                  Xp = train(net,V_Va_p', data.P');
             end
             if(layer1_neurons==11)
                  net = fitnet(layer1_neurons,'traingd');%funtion 1:Levenberg-Marquardt
                  Xq = train(net,V_Va_p', data.P');
             end
              if(layer1_neurons==12)
                  net = fitnet(layer1_neurons,'traingd');%funtion 1:Levenberg-Marquardt
                  Xpf = train(net,V_Va_p', data.P');
             end
        Xp_cos = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];
         end

    case 5 %compare sin and cos function as input data
        V_Va_p = [data.Va * pi / 180 data.V];
        layer1_neurons = 7;       
        net = fitnet(layer1_neurons,'trainlm');%funtion 1:Levenberg-Marquardt
        net_p_1 = train(net,V_Va_p', data.P');

        V_cosVa_p = [cos(data.Va * pi / 180) data.V] %use cos(theta) as input
        V_sinVa_p = [sin(data.Va * pi / 180) data.V] %use sin(theta) as input
        Xp = train(net,  V_sinVa_p', data.P');%sin network is stored in Xp
        Xp_cos = train(net,  V_cosVa_p', data.P');%cos network is store in Xp_cos

        net_p_2 = [];
        net_p_3 = [];
        net_q_1 = [];
        net_q_2 = [];
        net_q_3 = [];
        Xq  = [];
        Xpf = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];
     
      case 6 %changing sigmoid function
          %Hidden layer:1,  neurons: 7
          %logsig(n) = 1 / (1 + exp(-n))
          %tansig(N) = 2/(1+exp(-2*N))-1


        V_Va_p = [data.Va * pi / 180 data.V];
        layer1_neurons = 7;       
        net = fitnet(layer1_neurons,'trainlm');
        net.layers{1}.transferFcn = 'tansig';
        net.layers{2}.transferFcn = 'tansig';
        net_p_1 = train(net,V_Va_p', data.P'); %net->tanh(x)
        net.layers{1}.transferFcn = 'logsig';
        net.layers{2}.transferFcn = 'logsig';
        net_q_1 = train(net,V_Va_p', data.P');
        net = fitnet(layer1_neurons,'trainlm'); %net->Sigmoid(x)
        net.layers{1}.transferFcn = 'poslin';
        net.layers{2}.transferFcn = 'poslin';
        net_p_2 = train(net,V_Va_p', data.P'); %net->Relu(x)
        net_p_3 = [];
        net_q_2 = [];
        net_q_3 = [];
        Xp_cos = [];
        Xp = [];
        Xq  = [];
        Xpf = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];




    case 8 %can only be used in case 3cs
        for i = 1 : num_load 
            p = data.P(:, i); %make Y
            V_Va_p = [data.Va * pi / 180 data.V ones(size(data.V, 1), 1)];%make A
            V_cosVa_p = [cos(data.Va * pi / 180) data.V ones(size(data.V, 1), 1)];%make A
            V_sinVa_p = [sin(data.Va * pi / 180) data.V ones(size(data.V, 1), 1)];%make A
            V_Va_p =  V_Va_p(:,1:(num_load+1));
            V_cosVa_p = V_cosVa_p(:,1:(num_load+1));
            V_sinVa_p = V_sinVa_p(:,1:(num_load+1));

            b = regress(p, V_Va_p);
            Xp(i, :) = b';% make X
            b = regress(p, V_cosVa_p);
            Xp_cos(i, :) = b';
            b - regress(p,  V_sinVa_p);
            Xq(i,:) = b'
        end



        net_q_1 = [];
        net_q_2 = [];
        net_q_3 = [];
        net_p_1 = [];
        net_p_2 = [];
        net_p_3 = [];
        Xp_cos = [];
 
        Xpf = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];
     
    case 9 % p,q nerual network
        V_Va_p = [data.Va * pi / 180 data.V];
        layer1_neurons = 7; 

        net = fitnet(layer1_neurons,'trainlm');
        Xp= train(net,V_Va_p', data.P');

        layer1_neurons = 40;  
        net = fitnet(layer1_neurons,'trainlm');
        Xq = train(net, V_Va_p', data.Q');
       
        net_p_1 = [];
        net_p_2 = [];
        net_p_3 = [];
        net_q_1 = [];
        net_q_2 = [];
        net_q_3 = [];
        Xp_cos = [];
  
        Xpf = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];
     
    case 7%Genetic Algorithm
        V_Va_p = [data.Va * pi / 180 data.V];
        [num_bus_row,num_bus_column] = size(data.P);
        num = 150;
        V_Va_p(:,num_bus_column+1 : (num_bus_column)*2)=[]; %subtract '1 colomn'
        input_train = V_Va_p(1:num,:)';
        output_train = data.P(1:num,:)';
        input_test =  V_Va_p(num+1:end,:)';
        output_test =data.P(num+1:end,:)';
    
        %% Normalisation
        [inputn,inputps]=mapminmax(input_train);% normalised to between [-1,1], inputps is used to do the same normalisation next time
        [outputn,outputps]=mapminmax(output_train);
        inputn_test=mapminmax('apply',input_test,inputps);% Normalisation of test sample data
        %% 节点个数
        inputnum=size(input_train,1);       
        outputnum=size(output_train,1);      
        hiddennum=10;

        %% 构建BP神经网络
        net0=newff(inputn,outputn,hiddennum,{'tansig','purelin'},'trainlm');
         %网络参数配置
        net0.trainParam.epochs=1000;         
        net0.trainParam.lr=0.01;                 
        net0.trainParam.goal=0.00001;                  
        net0.trainParam.show=25;              
        net0.trainParam.mc=0.01;                
        net0.trainParam.min_grad=1e-6;      
        net0.trainParam.max_fail=6;               
        [net0,tr0]=train(net0,inputn,outputn);
        [outputnum,~]=size(net0.lw{2,1});
        [~,inputnum]=size(net0.iw{1,1});
        an0=sim(net0,inputn_test); 
        test_simu0=mapminmax('reverse',an0,outputps); 

%% use Genetic to find the best weights and bias

%网络参数配置
        net.trainParam.epochs=1000;     
        net.trainParam.lr=0.01;                 
        net.trainParam.goal=0.00001;                   
        net.trainParam.show=25;             
        net.trainParam.mc=0.01;               
        net.trainParam.min_grad=1e-6;
        net.trainParam.max_fail=6;              

        
net=newff(inputn,outputn,hiddennum,{'tansig','purelin'},'trainlm');
save data inputnum hiddennum outputnum net inputn outputn  inputn_test outputps output_test

% Initialize ga parameters
PopulationSize_Data=25;   
MaxGenerations_Data=20;   %
CrossoverFraction_Data=0.8;  %crossover propability
MigrationFraction_Data=0.2;  %crossover propability
nvars=inputnum*hiddennum+hiddennum+hiddennum*outputnum+outputnum;    %Number of independent variables
lb=repmat(-2,nvars,1);  
ub=repmat(-2,nvars,1);   

% calls to genetic algorithm functions

options = optimoptions('ga');
options = optimoptions(options,'PopulationSize', PopulationSize_Data);
options = optimoptions(options,'CrossoverFraction', CrossoverFraction_Data);
options = optimoptions(options,'MigrationFraction', MigrationFraction_Data);
options = optimoptions(options,'MaxGenerations', MaxGenerations_Data);
options = optimoptions(options,'SelectionFcn', @selectionroulette);   
options = optimoptions(options,'CrossoverFcn', @crossovertwopoint);  
options = optimoptions(options,'MutationFcn', {  @mutationgaussian [] [] });  
options = optimoptions(options,'Display', 'iter');    
options = optimoptions(options,'PlotFcn', { @gaplotbestf });    


%solve


[x,fval] = ga(@costfunction,nvars,[],[],[],[],lb,ub,[],[],options);

%% Assigning optimal initial threshold weights to the network for prediction

% % % Value prediction using BP network optimized by genetic algorithm

% W1 = net.iw{1, 1}% weights for input layers to intermediate layers

% B1 = net.b{1}% threshold of neurons in the intermediate layers

%

% W2 = net.lw{2,1}% weights of the intermediate layers to the output layer

% B2 = net.b{2}% threshold of each neuron in the output layer




setdemorandstream(pi);

w1=x(1:inputnum*hiddennum);
B1=x(inputnum*hiddennum+1:inputnum*hiddennum+hiddennum);
w2=x(inputnum*hiddennum+hiddennum+1:inputnum*hiddennum+hiddennum+hiddennum*outputnum);
B2=x(inputnum*hiddennum+hiddennum+hiddennum*outputnum+1:inputnum*hiddennum+hiddennum+hiddennum*outputnum+outputnum);

net.iw{1,1}=reshape(w1,hiddennum,inputnum);
net.lw{2,1}=reshape(w2,outputnum,hiddennum);
net.b{1}=reshape(B1,hiddennum,1);
net.b{2}=reshape(B2,outputnum,1);

%% Optimized neural network training
[net,tr]=train(net,inputn,outputn);
Xq = net;




%% Optimised neural network test
an1=sim(net,inputn_test);
test_simu1=mapminmax('reverse',an1,outputps); % Reduction of the data obtained
% from the simulation to the original order of magnitude
test_real = data.P(151:200,:)';
%Test accuracy
ha.bp =  mse(test_simu0,output_test)
ha.ga =  mse(test_simu1,output_test)
error.ga = mean(mean(abs(test_simu1-output_test)));
error.bp = mean(mean(abs(test_simu0-output_test)));
[~,dimension] = size(output_test);


%sum of percentage error

temp = abs(test_simu0-output_test)./abs(output_test); %funtion 1:Levenberg-Marquardt
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.simPBP = mean(mean(temp)) * 100;
temp = abs(test_simu1-output_test)./abs(output_test); %funtion 1:Levenberg-Marquardt
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.simPBPGA = mean(mean(temp)) * 100;

figure
plot(1:dimension,mean(abs(test_simu1-output_test)),'b-*');
hold on 
plot(1:dimension,mean(abs(test_simu0-output_test)),'mo-');
title('GA +BP vs BP (9 buses)');
ylabel('Error (absolute value)');
xlabel('Samples');
legend('Bp+GA error','BP error');
hold off;

        net_q_1 = [];
        net_q_2 = [];
        net_q_3 = [];
        
        net_p_1 = [];
        net_p_2 = [];
        net_p_3 = [];
        Xp_cos = [];
        Xp = [];
        Xq = [];
        Xpf = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];




      case 10
        %Genetic Algorithm
        V_Va_p = [data.Va * pi / 180 data.V];
        [num_bus_row,num_bus_column] = size(data.Q);
        num = 150;
        V_Va_p(:,num_bus_column+1 : (num_bus_column)*2)=[]; %subtract '1 colomn'
        input_train = V_Va_p(1:num,:)';
        output_train = data.Q(1:num,:)';
        input_test =  V_Va_p(num+1:end,:)';
        output_test =data.Q(num+1:end,:)';
    
        %% Normalisation
        [inputn,inputps]=mapminmax(input_train);
        [outputn,outputps]=mapminmax(output_train);
        inputn_test=mapminmax('apply',input_test,inputps);
        %% Number of neurons
        inputnum=size(input_train,1);     %input layer neurons
        outputnum=size(output_train,1);   %output layer neurons
        hiddennum=40;

        %% Initialise BP Algorithm
        net0=newff(inputn,outputn,hiddennum,{'tansig','purelin'},'trainlm');% Setup model
        
        net0.trainParam.epochs=1000;         % Maximal training times
        net0.trainParam.lr=0.01;                   % learning rate
        net0.trainParam.goal=0.00001;                    % Accecetable error
        net0.trainParam.show=25;                
        net0.trainParam.mc=0.01;                 % momentum factor 
        net0.trainParam.min_grad=1e-6;       % minimal gradient
        net0.trainParam.max_fail=6;             % maximal failure times
        [net0,tr0]=train(net0,inputn,outputn);
        [outputnum,~]=size(net0.lw{2,1});
        [~,inputnum]=size(net0.iw{1,1});
        an0=sim(net0,inputn_test); %
        test_simu0=mapminmax('reverse',an0,outputps); %denormali

%% use Genetic to find the best weights and bias

%network settings
        net.trainParam.epochs=1000;         % trining times 
        net.trainParam.lr=0.01;                   % learning rate
        net.trainParam.goal=0.00001;                    % testinhfata.
        net.trainParam.show=25;                % frequency
        net.trainParam.mc=0.01;                 % momentom factor
        net.trainParam.min_grad=1e-6;       % minimalgradient
        net.trainParam.max_fail=6;               % maximal falure times

     
net=newff(inputn,outputn,hiddennum,{'tansig','purelin'},'trainlm');
save data inputnum hiddennum outputnum net inputn outputn  inputn_test outputps output_test


%初始化ga参数
PopulationSize_Data=25;   
MaxGenerations_Data=30;   
CrossoverFraction_Data=0.8;  
MigrationFraction_Data=0.2;   
nvars=inputnum*hiddennum+hiddennum+hiddennum*outputnum+outputnum;    
lb=repmat(-1,nvars,1); 
ub=repmat(-1,nvars,1);  

%call genetic algorithm

options = optimoptions('ga');
options = optimoptions(options,'PopulationSize', PopulationSize_Data);
options = optimoptions(options,'CrossoverFraction', CrossoverFraction_Data);
options = optimoptions(options,'MigrationFraction', MigrationFraction_Data);
options = optimoptions(options,'MaxGenerations', MaxGenerations_Data);
options = optimoptions(options,'SelectionFcn', @selectionroulette);   %selection wheel
options = optimoptions(options,'CrossoverFcn', @crossovertwopoint);   %2-points crossover
options = optimoptions(options,'MutationFcn', {  @mutationgaussian [] [] });   %Gaussian mutation
options = optimoptions(options,'Display', 'iter');    
options = optimoptions(options,'PlotFcn', { @gaplotbestf });    
%solve


[x,fval] = ga(@costfunction,nvars,[],[],[],[],lb,ub,[],[],options);

% Use a BP network optimized by genetic algorithm for value prediction
% W1 = net.iw{1,1} % Weights from the input layer to the hidden layer
% B1 = net.b{1} % Threshold values for neurons in the hidden layer
%
% W2 = net.lw{2,1} % Weights from the hidden layer to the output layer
% B2 = net.b{2} % Threshold values for neurons in the output layer

setdemorandstream(pi);

w1=x(1:inputnum*hiddennum);
B1=x(inputnum*hiddennum+1:inputnum*hiddennum+hiddennum);
w2=x(inputnum*hiddennum+hiddennum+1:inputnum*hiddennum+hiddennum+hiddennum*outputnum);
B2=x(inputnum*hiddennum+hiddennum+hiddennum*outputnum+1:inputnum*hiddennum+hiddennum+hiddennum*outputnum+outputnum);

net.iw{1,1}=reshape(w1,hiddennum,inputnum);
net.lw{2,1}=reshape(w2,outputnum,hiddennum);
net.b{1}=reshape(B1,hiddennum,1);
net.b{2}=reshape(B2,outputnum,1);

%% Optimized neural network training
[net,tr]=train(net,inputn,outputn);
% Start training, where inputn and outputn are the input and output samples respectively
Xq = net;



%% Optimized neural network testing
an1=sim(net,inputn_test);
test_simu1=mapminmax('reverse',an1,outputps);
% Restore the simulated data to its original order of magnitude



test_real = data.Q(151:200,:)';

[~,dimension] = size(output_test);


%sum of percentage error

temp = abs(test_simu0-output_test)./abs(output_test); %funtion 1:Levenberg-Marquardt
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.simQ_BP = mean(mean(temp)) * 100;
temp = abs(test_simu1-output_test)./abs(output_test); %funtion 1:Levenberg-Marquardt
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.simQ_BPGA = mean(mean(temp)) * 100;

figure
plot(1:dimension,mean(abs(test_simu1-output_test)),'b-*');
hold on 
plot(1:dimension,mean(abs(test_simu0-output_test)),'mo-');
title('GA +BP vs BP (9 buses)');
ylabel('Error (absolute value)');
xlabel('Samples');
legend('Bp+GA error','BP error');
hold off;

        net_q_1 = [];
        net_q_2 = [];
        net_q_3 = [];
        
        net_p_1 = [];
        net_p_2 = [];
        net_p_3 = [];
        Xp_cos = [];
        Xp = [];
        Xq = [];
        Xpf = [];
        Xqf = [];
        Xpt = [];
        Xqt = [];

    otherwise
        error('no such regression method');
        
end





