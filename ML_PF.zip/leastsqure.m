function [parameter] = leastsqure(y,x)


%   __   __        _              _  _            _
%  | p_1   |      |  X_1 y_1 ...z_1|| parameter_1  |
%  | p_2   |      |  X_2 y_2 ...z_2|| parameter_2  |
%  | p_3   |      |  X_3 y_3 ...z_3|| parameter_3  | 
%  | p_4   |  __  |.         ...   || .            |
%  | .     |  __  |.         ...   || .            |
%  | .     |      |.         ...   || .            |
%  | .     |      |                || .            |
%  |_p_n __|      |_X_n y_n ...z_n_||_parameter_n _|

%initialize the parameter woth zeros we want to regress
n_colomn = size(x);
b = zeros(n_colomn, 1);
