function [layers_delta] = TestAccuracyNeurons(data,net_p_1, net_p_2, net_p_3, ...
           net_q_1, net_q_2, net_q_3,Xp,Xq,Xpf)

    [num_bus_row,num_bus_column] = size(data.P);
    V_Va_1 = [data.Va * pi / 180 data.V];

    data_p_4 = sim(net_p_1, V_Va_1');
    data_p_5 = sim(net_p_2, V_Va_1');
    data_p_6 = sim(net_p_3, V_Va_1');
    data_p_7 = sim(net_q_1, V_Va_1');
    data_p_8 = sim(net_q_2, V_Va_1');
    data_p_9 = sim(net_q_3, V_Va_1');
    data_p_10 = sim(Xp, V_Va_1');
    data_p_11 = sim(Xq, V_Va_1');
    data_p_12 = sim(Xpf, V_Va_1');
    data.P = data.P';
    %calculate the total error on different neural layer
   

    temp = abs(data.P -data_p_4)./abs(data.P);
    temp(find(isnan(temp)==1)) = [];
    temp(find(isinf(temp)==1)) = [];
    layers_delta(4,1) = mean(mean(temp))*100;

    temp = abs(data.P -data_p_5)./abs(data.P);
    temp(find(isnan(temp)==1)) = [];
    temp(find(isinf(temp)==1)) = [];
    layers_delta(5,1) = mean(mean(temp))*100;

    temp = abs(data.P -data_p_6)./abs(data.P);
    temp(find(isnan(temp)==1)) = [];
    temp(find(isinf(temp)==1)) = [];
    layers_delta(6,1) = mean(mean(temp))*100;

    temp = abs(data.P -data_p_7)./abs(data.P);
    temp(find(isnan(temp)==1)) = [];
    temp(find(isinf(temp)==1)) = [];
    layers_delta(7,1) = mean(mean(temp))*100;

    temp = abs(data.P -data_p_8)./abs(data.P);
    temp(find(isnan(temp)==1)) = [];
    temp(find(isinf(temp)==1)) = [];
    layers_delta(8,1) = mean(mean(temp))*100;

    temp = abs(data.P -data_p_9)./abs(data.P);
    temp(find(isnan(temp)==1)) = [];
    temp(find(isinf(temp)==1)) = [];
    layers_delta(9,1) = mean(mean(temp))*100;

    temp = abs(data.P -data_p_10)./abs(data.P);
    temp(find(isnan(temp)==1)) = [];
    temp(find(isinf(temp)==1)) = [];
    layers_delta(10,1) = mean(mean(temp))*100;

    temp = abs(data.P -data_p_11)./abs(data.P);
    temp(find(isnan(temp)==1)) = [];
    temp(find(isinf(temp)==1)) = [];
    layers_delta(11,1) = mean(mean(temp))*100;

    temp = abs(data.P -data_p_12)./abs(data.P);
    temp(find(isnan(temp)==1)) = [];
    temp(find(isinf(temp)==1)) = [];
    layers_delta(12,1) = mean(mean(temp))*100;
  

    

    plot(4:12,layers_delta(4:12))
    title 'Error with differetn neurons';
    xlabel ('Number of neurons');
    ylabel('Error');
