function PlotCosSinFun(delta)

hold on 
plot(1:1:10, delta.theta(1,1:10));
plot(1:1:10, delta.sin(1,1:10));
plot(1:1:10, delta.cos(1,1:10));
legend('theta', 'sin(theta)' );
plot(1:1:10, delta.cos(1,1:10),'DisplayName','cos(theta)');
hold off