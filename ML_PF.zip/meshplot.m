function [delta, test] = ...
    meshplot(num_train, num_load, data, Xp,Xp_cos, Xq, Xp_dlpf, Xq_dlpf, B)

for i = 1:num_train
test.p.angle(i, :) =[data.Va(i,:) * pi / 180 1] * Xp';
%     test.p.cos(i, :) =[cos(data.Va(i,2:3)) * pi / 180 1] * Xp_cos';
test.p.sin(i, :) =[sin(data.Va(i,:)) * pi / 180 1] * Xq';
        %Xq is the sin parameter linear regression matrix
    
end

temp = abs((data.P - test.p.angle)./data.P);
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.p.angle = mean(mean(temp)) * 100;

% temp = abs((data.P - test.p.cos)./data.P);
% temp(find(isnan(temp)==1)) = [];
% temp(find(isinf(temp)==1)) = [];
% delta.p.cos = mean(mean(temp)) * 100;

temp = abs((data.P - test.p.sin)./data.P);
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.p.sin = mean(mean(temp)) * 100;



subplot(1,2,1);
box on
scatter3(data.Va(:,2)* pi / 180,data.Va(:,3)* pi / 180,data.P(:,1),[], ...
    [0.8500 0.3250 0.0980],'filled'); %plot discrete points
hold on 

subplot(1,2,2);

scatter3(cos(data.Va(:,2)* pi / 180),cos(data.Va(:,3)* pi / 180),data.P(:,1), ...
    [],[0.4660 0.6740 0.1880],'filled'); %plot discrete points
hold on 
x1fit = min(data.Va(:,2)* pi / 180):0.01:max(data.Va(:,2)* pi / 180);
x2fit = min(data.Va(:,3)* pi / 180):0.01:max(data.Va(:,3)* pi / 180);
x1fitcos = min(cos(data.Va(:,2)* pi / 180)):0.01:max(cos(data.Va(:,2)* pi / 180));
x2fitcos = min(cos(data.Va(:,3)* pi / 180)):0.01:max(cos(data.Va(:,3)* pi / 180));
[X1FIT,X2FIT] = meshgrid(x1fit,x2fit); 
[X1FIT_cos,X2FIT_cos] = meshgrid(x1fitcos,x2fitcos); 

subplot(1,2,1);
Y = X1FIT.*Xp(1,1)+X2FIT.*Xp(1,2)+Xp(1,3);
mesh(X1FIT,X2FIT,Y);
xlabel('Angle x1') %设置X轴的名称  
ylabel('Angle x2') %设置y轴的名称  
zlabel('P (W)')  %设置z轴的名称

subplot(1,2,2);
Y_cos = X1FIT_cos.*Xp_cos(1,1)+X2FIT_cos.*Xp_cos(1,2)+Xp_cos(1,3);
mesh(X1FIT_cos,X2FIT_cos,Y_cos);


xlabel('Cos x1') %设置X轴的名称  
ylabel('Cos x2') %设置y轴的名称  
zlabel('P (W)')  %设置z轴的名称