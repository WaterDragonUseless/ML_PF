function [delta] = TestAccuracyNeural(data,net_p_1, net_p_2, ...
    net_p_3, net_q_1, net_q_2, net_q_3,i, V_Va_p_old, Data_Q_old)

V_Va_1 = [data.Va * pi / 180 data.V];

data_p_1 = sim(net_p_1, V_Va_1'); %LM
data_p_3 = sim(net_p_3, V_Va_1'); %GD

% [p_train, ps_input] = mapminmax(V_Va_p_old', 0,1);
% p_test = mapminmax('apply',V_Va_1', ps_input);
% 
% [t_train, ps_output] = mapminmax(Data_Q_old', 0,1);
% t_test = mapminmax('apply',data.Q', ps_output);
%     
% net = newff(p_train, t_train, 7);
% net = fitnet(7,'trainlm');%funtion 1:Levenberg-Marquardt
% net_normalized = train(net,p_train, t_train);
% 
%  t_sim1 = sim(net_normalized,p_train);
%  t_sim2 = sim(net_normalized,p_test);
% 
%  T_sim1 = mapminmax('reverse', t_sim1, ps_output);
%  T_sim2 = mapminmax('reverse', t_sim2, ps_output);%test data


 data.P = data.P';
 data.Q = data.Q';
[num_bus_row,num_bus_column] = size(data.P);
% deltaQ = abs(data.Q(1:num_bus_row,:) -data_q_1(1:num_bus_row,:))*100./abs(data.Q(1:num_bus_row,:));
% deltaQ_normalized = abs(data.Q(1:num_bus_row,:) -T_sim2(1:num_bus_row,:))*100./abs(data.Q(1:num_bus_row,:));
% deltaP = abs(data.P(1:num_bus_row,:) -data_p_1(1:num_bus_row,:))*100./abs(data.P(1:num_bus_row,:));
%plot difference with real values from Bus 1 to x
% % 
% % figure(1);%TOTAL SAMPLES
% % deltaP = abs(data.P(1:num_bus_row,:) -data_p_1(1:num_bus_row,:))*100./abs(data.P(1:num_bus_row,:));
% % mesh(1:num_bus_column,1:num_bus_row, deltaP);
% % title 'Percentage P error ';
% % xlabel ('Samples');
% % ylabel('Bus');
% % zlabel('Error P(%)');
% % 
% % figure(2);
% % mesh(1:num_bus_column,1:num_bus_row, deltaQ);
% % title 'Percentage Q error ';
% % xlabel ('Samples');
% % ylabel('Bus');
% % zlabel('Error Q(%)');
% % 
% % AVG P error from TOTAL SAMPLES
% % figure(3);
% % deicard rows and colomns with Nan
% % j = deltaP;
% % j = deltaP(find(~isnan(deltaP)));
% % deltaP(any(isnan(deltaP)'),:) = [];
% % B = deltaP(all(~isnan(deltaP),2),:);
% % deltaP = deltaP(:,all(~isnan(deltaP),1));
% % deltaP = mean(deltaP');
% % [~,y] = size(deltaP);
% % plot average error% versus buses(except nan bus)
% % plot(1:y,deltaP(1:y));
% % title 'P error on each buses';
% % xlabel ('Buses');
% % ylabel('Error (%)');
% % 
% % AVG Q error from TOTAL SAMPLES
% % figure(4);
% % deicard rows and colomns with Nan
% % j = deltaQ;
% % j = deltaQ(find(~isnan(deltaQ)));
% % deltaQ(any(isnan(deltaQ)'),:) = [];
% % B = deltaQ(all(~isnan(deltaQ),2),:);
% % deltaQ = deltaQ(:,all(~isnan(deltaQ),1));
% % deltaQ = mean(deltaQ');
% % [~,y] = size(deltaQ);
% % plot average error% versus buses(except nan bus)
% % plot(1:y,deltaQ(1:y));
% % title 'Q error on each buses';
% % xlabel ('Buses(excluding Nah buses)');
% % ylabel('Error (%)');
% % 
% % AVG Q error from TOTAL SAMPLES
% % (Comparison between Unormalized and Normalized input)
% % figure(5);
% % deicard rows and colomns with Nan
% % j = deltaQ_normalized;
% % j = deltaQ_normalized(find(~isnan(deltaQ_normalized)));
% % deltaQ_normalized(any(isnan(deltaQ_normalized)'),:) = [];
% % B = deltaQ_normalized(all(~isnan(deltaQ_normalized),2),:);
% % deltaQ_normalized =deltaQ_normalized (:,all(~isnan(deltaQ_normalized),1));
% % deltaQ_normalized = mean(deltaQ_normalized');
% % [~,y] = size(deltaQ_normalized);
% % plot average error% versus buses(except nan bus)
% %  hold on;
% % plot(1:y,deltaQ(1:y));
% % plot(1:y,deltaQ_normalized(1:y));
% % legend('Unnormalized input', 'Normalized input' );
% % title('Difference between normalized and unormalized input');
% % xlabel ('Buses(excluding Nah buses)');
% % ylabel('Error (%)');
% % hold off
% % 


% if (i == 1)
% figure(1);
% ans_Nerual_LM = abs(data.P(1:num_bus_row,:) -data_p_1(1:num_bus_row,:))*100./abs(data.P(1:num_bus_row,:));
% mesh(1:num_bus_column,1:num_bus_row, ans_Nerual_LM);
% title 'Percentsge error from bus 1 to bus 30 (Neural LM)';
% xlabel ('samples');
% ylabel('bus');
% zlabel('error_p (%)');
% 
% figure(2);
% ans_Nerual_Bayes = abs(data.P(1:num_bus_row,:) -data_p_2(1:num_bus_row,:))*100./abs(data.P(1:num_bus_row,:));
% mesh(1:num_bus_column,1:num_bus_row, ans_Nerual_Bayes);
% title 'Percentsge error from bus 1 to bus 30 (Neural Bayes)';
% xlabel ('samples');
% ylabel('bus');
% zlabel('error_p (%)');
% 
% figure(3);
% ans_Nerual_GD = abs(data.P(1:num_bus_row,:) -data_p_3(1:num_bus_row,:))*100./abs(data.P(1:num_bus_row,:));
% mesh(1:num_bus_column,1:num_bus_row, ans_Nerual_GD );
% title 'Percentsge error from bus 1 to bus 30 (Gradient Descent)';
% xlabel ('samples');
% ylabel('bus');
% zlabel('error_p (%)');
% 


temp = abs(data.P -data_p_1)./abs(data.P); %funtion 1:Levenberg-Marquardt
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.Neural_p_1 = mean(mean(temp)) * 100;
% 
% temp = abs((data.P -data_q_1)./abs(data.P)); %funtion 1:Levenberg-Marquardt
% temp(find(isnan(temp)==1)) = [];
% temp(find(isinf(temp)==1)) = [];
% delta.Neural_q_1 = mean(mean(temp)) * 100;
% 
% temp = abs((data.P -data_p_2)./data.P); %funtion 2: Bayesian Regularization
% temp(find(isnan(temp)==1)) = [];
% temp(find(isinf(temp)==1)) = [];
% delta.Neural_p_2 = mean(mean(temp)) * 100;
% 
% temp = abs((data.P -data_q_2)./data.P); %funtion 2: Bayesian Regularization
% temp(find(isnan(temp)==1)) = [];
% temp(find(isinf(temp)==1)) = [];
% delta.Neural_q_2 = mean(mean(temp)) * 100;


temp = abs(data.P -data_p_3)./abs(data.P);%funtion 3: Gradient Descent
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.Neural_p_3 = mean(mean(temp)) * 100;

% temp = abs((data.P -data_q_3)./abs(data.P)); %funtion 3: Gradient Descent
% temp(find(isnan(temp)==1)) = [];
% temp(find(isinf(temp)==1)) = [];
% delta.Neural_q_3 = mean(mean(temp)) * 100;

