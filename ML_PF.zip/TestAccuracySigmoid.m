function [delta]=TestAccuracySigmoid(data,net_p_1, net_p_2, net_p_3, ...
           net_q_1, net_q_2, net_q_3,Xp,Xq,Xpf)

    V_Va_1 = [data.Va * pi / 180 data.V];

    testP.tansig = sim(net_p_1, V_Va_1');
    testP.logsig = sim(net_q_1, V_Va_1');
    testP.ReLu = sim(net_p_2, V_Va_1');
    data.P = data.P';
    [num_bus_row,num_bus_column] = size(data.P);

    temp = abs((data.P - testP.tansig)./data.P); %error matrix
    figure(1);%error matrix visualization 
    mesh(1:num_bus_column,1:num_bus_row, temp);
    title 'P error-tanh(x) ';
    xlabel ('Samples');
    ylabel('Bus');
    zlabel('Error P(%)');
    temp(find(isnan(temp)==1)) = [];%mean error 
    temp(find(isinf(temp)==1)) = [];
    delta.p.tansig = mean(mean(temp)) * 100;
    


    temp = abs((data.P - testP.logsig)./data.P); %error matrix
    figure(2);%error matrix visualization 
    mesh(1:num_bus_column,1:num_bus_row, temp);
    title 'P error-sigmoid(x) ';
    xlabel ('Samples');
    ylabel('Bus');
    zlabel('Error P(%)');
    temp(find(isnan(temp)==1)) = [];%mean error 
    temp(find(isinf(temp)==1)) = [];
    delta.p.logsig = mean(mean(temp)) * 100;

    


    temp = abs((data.P - testP.ReLu)./data.P);%error matrix
    figure(3);%error matrix visualization
    mesh(1:num_bus_column,1:num_bus_row, temp);
    title 'P error-Relu(x) ';
    xlabel ('Samples');
    ylabel('Bus');
    zlabel('Error P(%)');
    temp(find(isnan(temp)==1)) = [];%mean error
    temp(find(isinf(temp)==1)) = [];
    delta.p.ReLu = mean(mean(temp)) * 100;
    
    
