% This is the start up m-file of the data-driven power flow linearization master
% Author: Yi Tong built neural networks and genetic algorithms to regress the 
%active/reactive power flow. Yi Tong compared the result with the method 
%The Startup and Generate is developed by Liu Y, et al. Data-Driven Power Flow Linearization: A Regression Approach
clc;
clear;
%% define parameters
generate_data = 1;%1,data generation is needed; 0,data is already generated
generate_test_data = 1;%1,data generation is needed; 0,data is already generated
upper_bound = 1.2;%upper bound of generated load
lower_bound = 0.8;%lower bound of generated load
regression = 0; %0-least squares, BP 1-PLS 2- Bayesian 3-BP 4-neurons ...
% 5-input data(normalization, sincos), 6-active functions, 7-GA, 8-cos,sin 
% 9-PQ



for_or_inv = 0;% 0-forward regression;1-inverse regression 

G_range = 0.1; %range of power generation variations
Q_range = 0.25; %range of Q variations
Q_per = 0.2; %Q percentage on P
V_range = 0.01; %range of voltage magnitude variations of PV buses
L_range = 0.05; %range of load in different nodes
L_corr = 0.9; %covariance
Va_range = 7;%degree
Va_num = [];
dc_ac = 0; %0-dc;1-ac;
random_load = 1; %1,random 0,not random with bounder 2,not random with covariance

data_size = 200;% training data size
data_size_test =300;% testing data size
case_name = 'case5';
address = '';% address to read and save the data fss

%%  training data generation
data_name = [address case_name '_training_data'];
if (generate_data)
    mpc = ext2int(loadcase(case_name));
    [ref, pv, pq] = bustypes(mpc.bus, mpc.gen);
    DataGeneration(case_name, Q_per, data_name, dc_ac, G_range, ...
        upper_bound, lower_bound, Q_range, V_range, data_size, L_range, ...
        random_load, Va_range, ref, L_corr);      
end
load([data_name,'.mat']);

%%  linear regression
%  get bus index lists of each type of bus
mpc = ext2int(loadcase(case_name));
[ref, pv, pq] = bustypes(mpc.bus, mpc.gen);

[Xp_dlpf, Xq_dlpf,~, ~, ~] = DLPF(mpc);
Xp_dlpf = full(Xp_dlpf);
Xq_dlpf = full(Xq_dlpf);
 V_Va_p_old= [data.Va * pi / 180 data.V];
 Data_Q_old = data.Q;



    [Xp, Xp_cos, Xq, Xpf, Xqf, Xpt, Xqt, net_p_1, net_p_2, net_p_3,net_q_1, net_q_2, net_q_3] =...
        RegressionForward(regression, num_load, data, address, case_name);


%% generate testing data
upper_bound = 1.2;
lower_bound = 0.8;
data_name = [address case_name '_testing_data'];

sum_p = 0;
sum_q = 0;

for i  = 1:1

    if (generate_test_data)
        DataGeneration(case_name, Q_per, data_name, dc_ac, G_range,...
        upper_bound, lower_bound, Q_range, V_range, data_size_test, L_range, ...
        random_load, Va_range, ref, L_corr); 
    end
    load([data_name,'.mat']);
    num_train = size(data.P, 1);
   
     
      %%verify the accuracy
    if (regression== 0 || regression == 1  )
          [delta, test] = ...
           TestAccuracyForward(num_train, data, Xp,Xp_cos, Xq, Xp_dlpf, Xq_dlpf, B, Xpt, Xqt);
  
    elseif (for_or_inv == 0 && regression == 3)
           [delta] = TestAccuracyNeural(data,net_p_1, net_p_2, net_p_3, ...
           net_q_1, net_q_2, net_q_3, i, V_Va_p_old, Data_Q_old);

    elseif (for_or_inv == 0 && regression == 4)
        [layers_delta] = ...
        TestAccuracyNeurons(data,net_p_1, net_p_2, net_p_3, ...
           net_q_1, net_q_2, net_q_3,Xp,Xq,Xpf);
   elseif (for_or_inv == 0 && regression == 5)
      for j = 1:10    
       [theta_1,cos_1,sin_1] = TestAccuracySinCos(net_p_1,Xp,Xp_cos,data,j);
       delta.cos(1,j)=cos_1;
       delta.sin(1,j)=sin_1;
       delta.theta(1,j)=theta_1;
        
       %regenerate test data
        DataGeneration(case_name, Q_per, data_name, dc_ac, G_range,...
        upper_bound, lower_bound, Q_range, V_range, data_size_test, L_range, ...
        random_load, Va_range, ref, L_corr); 
        load([data_name,'.mat']);
      end
        PlotCosSinFun(delta);
  elseif (for_or_inv == 0 && regression == 6)
           [delta] = TestAccuracySigmoid(data,net_p_1, net_p_2, net_p_3, ...
           net_q_1, net_q_2, net_q_3,Xp,Xq,Xpf);
    
    
  elseif (for_or_inv == 0 && regression == 7)
             PlotGABP();
             PlotTrainingNumberError();


  elseif (for_or_inv == 0 && regression == 8)
          [delta, test] = ...
          meshplot(num_train,num_load, data, Xp,Xp_cos, Xq, Xp_dlpf, Xq_dlpf, B);

  elseif (for_or_inv == 0 && regression == 9)
          [delta] = ...
           TestAccuracyPQ(num_load, data, Xp,Xq);
    
    end
end
