function PlotTrainingNumberError()
% run Figure 4-1, but needs to be run in cmommand windows.
load('TrainingOverSize.mat')

figure;
plot(A(1,4:10), A(2, 4:10),'b-*');
hold on;
plot(A(1,1:10), A(3, 1:10),'c-h');
plot(A(1,2:10), A(4, 2:10),'r-o');
plot(A(1,2:10), A(5, 2:10),'m-x');

xlabel('Traning number / Case size');
ylabel('Average Error');
legend('Case 5','Case 30', 'Case 33', 'Case 57');