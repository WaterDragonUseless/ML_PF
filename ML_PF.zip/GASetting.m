function GASetting()

options = optimoptions('ga');
options = optimoptions(options,'PopulationSize', PopulationSize_Data);
options = optimoptions(options,'CrossoverFraction', CrossoverFraction_Data);
options = optimoptions(options,'MigrationFraction', MigrationFraction_Data);
options = optimoptions(options,'MaxGenerations', MaxGenerations_Data);
options = optimoptions(options,'SelectionFcn', @selectionroulette);   %轮盘赌选择
options = optimoptions(options,'CrossoverFcn', @crossovertwopoint);   %两点交叉
options = optimoptions(options,'MutationFcn', {  @mutationgaussian [] [] });   %高斯变异
options = optimoptions(options,'Display', 'off');    %‘off’为不显示迭代过程，‘iter’为显示迭代过程
options = optimoptions(options,'PlotFcn', { @gaplotbestf });    %最佳适应度作图