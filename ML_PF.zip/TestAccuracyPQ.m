
function [delta]=TestAccuracyPQ(num_load, data, Xp,Xq);

V_Va_1 = [data.Va * pi / 180 data.V];
simP = sim(Xp, V_Va_1'); %p
simQ = sim(Xq, V_Va_1');%q

 data.P = data.P';
 data.Q = data.Q';

[num_bus_row,num_bus_column] = size(data.P);

temp = abs(data.P -simP)./abs(data.P); %funtion 1:Levenberg-Marquardt
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.simP = mean(mean(temp)) * 100;

temp = abs(data.Q -simQ)./abs(data.Q); %funtion 1:Levenberg-Marquardt
temp(find(isnan(temp)==1)) = [];
temp(find(isinf(temp)==1)) = [];
delta.simQ = mean(mean(temp)) * 100;
